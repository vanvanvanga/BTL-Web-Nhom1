# Đề tài: Website quản lý sách trong thư viện

```
Nộp 1 file nén gồm:
- Code
- Dữ liệu mẫu
- Báo cáo tóm tắt (dùng một trong các định dạng .md, .txt, .pdf, .docx, .pptx), nội dung gồm các mục:
+ các chức năng
+ mức độ hoàn thiện
+ phân công nhiệm vụ của từng thành viên
+ hướng dẫn cài đặt và sử dụng
```
